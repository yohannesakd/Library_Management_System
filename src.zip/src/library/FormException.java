package library;

public class FormException extends Exception {
    FormException(String message){
        super(message);
    }
}
